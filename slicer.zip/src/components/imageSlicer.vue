<template>
  <v-container >
    <v-responsive class="d-flex align-center text-center fill-height">
      <div class="text-body-2 font-weight-light mb-n1">Welcome to</div>
      <h1 class="text-h2 font-weight-bold">Image Slicer</h1>

      <v-row class="mt-10">
        <v-col cols="12" :md="splitImages.length > 0 ? 6 : 12">
          <div class="d-flex mt-10">
            <v-file-input
              label="Please Choose Image"
              accept="image/png, image/jpeg, image/jpg"
              @change="handleFileChange"
              @clear="clear"
            ></v-file-input>
            <v-btn color="error" size="small" v-if="selectedImg" density="default" @click="clear" icon="mdi-close"></v-btn>
          </div>

          <v-img v-if="selectedImg" :src="selectedImg"> </v-img>
          <v-divider
      class="ms-3"
      inset
      vertical
    ></v-divider>
        </v-col>
        <v-col cols="12" md="6">
          <div class="mt-3" v-if="splitImages.length > 0">
            <p class="font-weight-bold text-h5">Split Images :</p>
            <v-row class="mt-2">
              <v-col
                v-for="(image, index) in splitImages"
                :key="index"
                cols="12"
                md="6"
              >
                <v-img class="pointer rounded-lg elevation-3" :src="image.dataUrl" alt="Split image" />
              </v-col>
            </v-row>
          </div>
        </v-col>
      </v-row>
    </v-responsive>
  </v-container>
</template>
<script>
  export default {
    data() {
      return {
        file: null,
        splitImages: [],
        selectedImg: "",
      };
    },
    methods: {
      handleFileChange(event) {
        const file = event.target.files[0];
        this.file = file;
        this.selectedImg = URL.createObjectURL(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          const image = new Image();
          image.src = e.target.result;
          image.onload = () => {
            // Calculate quarter dimensions
            const width = image.width / 2;
            const height = image.height / 2;

            // Create and fill canvases
            for (let y = 0; y < 2; y++) {
              for (let x = 0; x < 2; x++) {
                const canvas = document.createElement("canvas");
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext("2d");
                ctx.drawImage(
                  image,
                  x * width,
                  y * height,
                  width,
                  height,
                  0,
                  0,
                  width,
                  height
                );
                this.splitImages.push({
                  dataUrl: canvas.toDataURL("image/png"),
                });
              }
            }
          };
        };
        reader.readAsDataURL(file);
      },
      clear() {
        this.selectedImg = "";
        this.splitImages = [];
      },
    },
  };
</script>
<style>
.pointer{
  cursor: pointer;
}
</style>